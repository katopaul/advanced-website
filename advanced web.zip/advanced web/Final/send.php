<?php
// Database connection parameters
$servername = "localhost";
$username = "root"; // Replace with your MySQL username
$password = ""; // Replace with your MySQL password
$dbname = "kichwamba";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect and sanitize form inputs
    $name = $conn->real_escape_string($_POST['f1']);
    $phone = $conn->real_escape_string($_POST['f2']);
    $city = $conn->real_escape_string($_POST['f3']);
    $country = $conn->real_escape_string($_POST['f4']);
    $message = $conn->real_escape_string($_POST['f5']);

    // Insert data into the contact_form table
    $sql = "INSERT INTO contact_form (name, phone, city, country, message)
            VALUES ('$name', '$phone', '$city', '$country', '$message')";

    if ($conn->query($sql) === TRUE) {
        echo "Thank you, $name, for contacting us! Your message has been received.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close connection
$conn->close();
?>
